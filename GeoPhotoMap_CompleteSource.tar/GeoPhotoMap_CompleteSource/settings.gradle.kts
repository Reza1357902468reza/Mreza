rootProject.name = "GeoPhotoMap"
include(":app")
