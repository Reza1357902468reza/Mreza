plugins {
    kotlin("jvm") version "1.8.21" apply false
    id("com.android.application") version "8.1.1" apply false
}
