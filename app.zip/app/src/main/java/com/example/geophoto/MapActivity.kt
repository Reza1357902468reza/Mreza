package com.example.geophoto

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import org.osmdroid.config.Configuration
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker

class MapActivity : AppCompatActivity() {
    private lateinit var mapView: MapView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().load(this, this.getPreferences(MODE_PRIVATE))

        setContentView(R.layout.activity_map)
        mapView = findViewById(R.id.mapview)

        val lat = intent.getDoubleExtra("lat", Double.NaN)
        val lng = intent.getDoubleExtra("lng", Double.NaN)
        val point = if (!lat.isNaN() && !lng.isNaN()) GeoPoint(lat, lng) else GeoPoint(0.0, 0.0)

        mapView.controller.setZoom(16.0)
        mapView.controller.setCenter(point)

        if (!lat.isNaN() && !lng.isNaN()) {
            val marker = Marker(mapView)
            marker.position = point
            marker.title = "Photo location"
            mapView.overlays.add(marker)
        }
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause()
    }
}
